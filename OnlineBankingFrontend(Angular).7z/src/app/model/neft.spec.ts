import { Neft } from './neft';

describe('Neft', () => {
  it('should create an instance', () => {
    expect(new Neft()).toBeTruthy();
  });
});
