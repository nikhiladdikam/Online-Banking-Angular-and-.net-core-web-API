export class User{
    id : number;
    accountnumber : string='';
    setloginpassword : string='';
    confirmloginpassword : string='';
    settransactionpassword : string='';
    confirmtransactionpassword : string='';
    otp : string='';

}
