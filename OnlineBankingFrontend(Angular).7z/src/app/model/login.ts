export class Login {
    accountNumber : string='';
    loginPassword : string='';
    // confirmLoginPassword : string='';
    // transactionPassword : string='';
    // confirmTransactionPassword : string='';
}
