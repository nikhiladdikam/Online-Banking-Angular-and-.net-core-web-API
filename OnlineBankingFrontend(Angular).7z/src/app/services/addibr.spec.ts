// import { Addibr } from './addibr';

// describe('Addibr', () => {
//   it('should create an instance', () => {
//     expect(new Addibr()).toBeTruthy();
//   });
// });
