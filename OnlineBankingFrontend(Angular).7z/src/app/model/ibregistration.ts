export class Ibregistration {
    internetBankingID : number;
    accountNumber : string='';
    loginPassword : string='';
    confirmLoginPassword : string='';
    transactionPassword : string='';
    confirmTransactionPassword : string='';
    answer : string='';
}
