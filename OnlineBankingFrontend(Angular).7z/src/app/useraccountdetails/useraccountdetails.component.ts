import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-useraccountdetails',
  templateUrl: './useraccountdetails.component.html',
  styleUrls: ['./useraccountdetails.component.css']
})
export class UseraccountdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
