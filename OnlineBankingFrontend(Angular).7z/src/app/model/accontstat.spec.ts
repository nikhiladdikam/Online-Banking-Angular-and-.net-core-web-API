import { Accontstat } from './accontstat';

describe('Accontstat', () => {
  it('should create an instance', () => {
    expect(new Accontstat()).toBeTruthy();
  });
});
