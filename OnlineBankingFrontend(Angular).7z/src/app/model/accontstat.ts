export class Accontstat {

        accountStatId: any='';
        accountNumber: any='';
        accountType: string='';
        balance: any='';
}
