export class openacc{
    accountNumber : number;
  firstName : string;
  middleName : string;
  lastName : string;
    fathersName : string;
    phoneNumber :number;
   emailId : string;
   aadharNumber : number;
   dob : number;
  address : string;   
  occupationDetails : string;

}
