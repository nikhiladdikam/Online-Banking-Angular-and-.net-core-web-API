import { Forgotservice } from './forgotservice';

describe('Forgotservice', () => {
  it('should create an instance', () => {
    expect(new Forgotservice()).toBeTruthy();
  });
});
