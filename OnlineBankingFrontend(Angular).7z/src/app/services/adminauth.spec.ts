import { Adminauth } from './adminauth';

describe('Adminauth', () => {
  it('should create an instance', () => {
    expect(new Adminauth()).toBeTruthy();
  });
});
