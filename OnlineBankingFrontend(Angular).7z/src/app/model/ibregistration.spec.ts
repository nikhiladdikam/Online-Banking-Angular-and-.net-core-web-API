import { Ibregistration } from './ibregistration';

describe('Ibregistration', () => {
  it('should create an instance', () => {
    expect(new Ibregistration()).toBeTruthy();
  });
});
