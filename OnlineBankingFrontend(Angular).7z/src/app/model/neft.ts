export class Neft {
    fromAccount : number;
    toAccount : number;
    amount : number;
    transactionDate: Date;
    remarks : string;
    //transactionPassword: string;
}
