import { Rtgs } from './rtgs';

describe('Rtgs', () => {
  it('should create an instance', () => {
    expect(new Rtgs()).toBeTruthy();
  });
});
