import { Imps } from './imps';

describe('Imps', () => {
  it('should create an instance', () => {
    expect(new Imps()).toBeTruthy();
  });
});
