export class Imps {
    fromAccount : number;
    toAccount : number;
    amount : number;
    transactionDate: Date;
    maturityInstruction : string;
    remarks : string;
    //transactionPassword: string;

}
