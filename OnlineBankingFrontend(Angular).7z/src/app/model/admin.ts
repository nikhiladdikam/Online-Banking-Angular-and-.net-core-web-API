export class Admin {
    adminEmail : string='';
    password : string='';

}
