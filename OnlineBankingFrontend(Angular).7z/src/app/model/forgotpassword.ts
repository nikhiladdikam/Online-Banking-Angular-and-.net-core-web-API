export class Forgotpassword {
    accountNumber: string;
    answer: string;
}
