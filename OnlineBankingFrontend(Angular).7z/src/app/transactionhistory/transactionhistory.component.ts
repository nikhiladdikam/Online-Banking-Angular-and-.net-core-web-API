import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transactionhistory',
  templateUrl: './transactionhistory.component.html',
  styleUrls: ['./transactionhistory.component.css']
})
export class TransactionhistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
